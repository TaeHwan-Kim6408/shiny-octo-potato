package com.example.practice.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RevenueVO {
    int revenueCode = 0;
    String revenueName = null;
    String revenueType = null;
}
